<?php include_once('wudata.php');?>

<?php echo $wuskydayTime2?>,<?php echo $wuskydayprecipIntensity2; ?>,
<?php echo $wuskydayTime3?>,<?php echo $wuskydayprecipIntensity3; ?>,
<?php echo $wuskydayTime4?>,<?php echo $wuskydayprecipIntensity4; ?>,

<?php echo $wuskydayTime5?>,<?php echo $wuskydayprecipIntensity5; ?>,
<?php echo $wuskydayTime6?>,<?php echo $wuskydayprecipIntensity6; ?>,
<?php echo $wuskydayTime7?>,<?php echo $wuskydayprecipIntensity7; ?>,

<?php echo $wuskydayTime8?>,<?php echo $wuskydayprecipIntensity8; ?>,
<?php echo $wuskydayTime9?>,<?php echo $wuskydayprecipIntensity9; ?>,
<?php echo $wuskydayTime10?>,<?php echo $wuskydayprecipIntensity10; ?>,