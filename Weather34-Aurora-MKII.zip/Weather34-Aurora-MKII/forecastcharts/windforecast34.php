<?php include_once('wudata.php');?>

<?php echo $wuskydayTime2?>,<?php echo $wuskydayWindGust2; ?>,
<?php echo $wuskydayTime3?>,<?php echo $wuskydayWindGust3; ?>,
<?php echo $wuskydayTime4?>,<?php echo $wuskydayWindGust4; ?>,
<?php echo $wuskydayTime5?>,<?php echo $wuskydayWindGust5; ?>,

<?php echo $wuskydayTime6?>,<?php echo $wuskydayWindGust6; ?>,
<?php echo $wuskydayTime7?>,<?php echo $wuskydayWindGust7; ?>,
<?php echo $wuskydayTime8?>,<?php echo $wuskydayWindGust8; ?>,
<?php echo $wuskydayTime9?>,<?php echo $wuskydayWindGust9; ?>,
<?php echo $wuskydayTime10?>,<?php echo $wuskydayWindGust10; ?>,