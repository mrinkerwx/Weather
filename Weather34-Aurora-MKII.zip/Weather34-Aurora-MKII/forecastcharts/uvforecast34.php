<?php include_once('wudata.php');?>

<?php echo $wuskydayTime2?>,<?php echo $wuskydayUV2; ?>,

<?php echo $wuskydayTime3?>,<?php echo $wuskydayUV3; ?>,
<?php echo $wuskydayTime4?>,<?php echo $wuskydayUV4; ?>,
<?php echo $wuskydayTime5?>,<?php echo $wuskydayUV5; ?>,

<?php echo $wuskydayTime6?>,<?php echo $wuskydayUV6; ?>,
<?php echo $wuskydayTime7?>,<?php echo $wuskydayUV7; ?>,
<?php echo $wuskydayTime8?>,<?php echo $wuskydayUV8; ?>,
<?php echo $wuskydayTime9?>,<?php echo $wuskydayUV9; ?>,
<?php echo $wuskydayTime10?>,<?php echo $wuskydayUV10; ?>,