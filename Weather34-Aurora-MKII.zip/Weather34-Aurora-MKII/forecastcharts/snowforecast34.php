<?php include_once('wudata.php');?>

<?php echo $wuskydayTime2?>,<?php echo $wuskydaysnow2; ?>,
<?php echo $wuskydayTime3?>,<?php echo $wuskydaysnow3; ?>,
<?php echo $wuskydayTime4?>,<?php echo $wuskydaysnow4; ?>,

<?php echo $wuskydayTime5?>,<?php echo $wuskydaysnow5; ?>,
<?php echo $wuskydayTime6?>,<?php echo $wuskydaysnow6; ?>,
<?php echo $wuskydayTime7?>,<?php echo $wuskydaysnow7; ?>,

<?php echo $wuskydayTime8?>,<?php echo $wuskydaysnow8; ?>,
<?php echo $wuskydayTime9?>,<?php echo $wuskydaysnow9; ?>,
<?php echo $wuskydayTime10?>,<?php echo $wuskydaysnow10; ?>,