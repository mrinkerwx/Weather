<?php include_once('wudata.php');?>
<?php echo $wuskydayTime?>,<?php echo $wuskydayPrecipProb; ?>,
<?php echo $wuskydayTime1?>,<?php echo $wuskydayPrecipProb1; ?>,
<?php echo $wuskydayTime2?>,<?php echo $wuskydayPrecipProb2; ?>,

<?php echo $wuskydayTime3?>,<?php echo $wuskydayPrecipProb3; ?>,
<?php echo $wuskydayTime4?>,<?php echo $wuskydayPrecipProb4; ?>,
<?php echo $wuskydayTime5?>,<?php echo $wuskydayPrecipProb5; ?>,

<?php echo $wuskydayTime6?>,<?php echo $wuskydayPrecipProb6; ?>,
<?php echo $wuskydayTime7?>,<?php echo $wuskydayPrecipProb7;?>,
<?php echo $wuskydayTime8?>,<?php echo $wuskydayPrecipProb8; ?>,