<?php include_once('wudata.php');?>

<?php echo $wuskydayTime2?>,<?php echo $wuskythunder2; ?>,
<?php echo $wuskydayTime3?>,<?php echo $wuskythunder3; ?>,
<?php echo $wuskydayTime4?>,<?php echo $wuskythunder4; ?>,

<?php echo $wuskydayTime5?>,<?php echo $wuskythunder5; ?>,
<?php echo $wuskydayTime6?>,<?php echo $wuskythunder6; ?>,
<?php echo $wuskydayTime7?>,<?php echo $wuskythunder7; ?>,

<?php echo $wuskydayTime8?>,<?php echo $wuskythunder8; ?>,
<?php echo $wuskydayTime9?>,<?php echo $wuskythunder9; ?>,
<?php echo $wuskydayTime10?>,<?php echo $wuskythunder10; ?>,