<?php include_once('wudata.php');?>

<?php echo $wuskydayTime2?>,<?php echo $wuskydayTempHigh2; ?>,
<?php echo $wuskydayTime3?>,<?php echo $wuskydayTempHigh3; ?>,
<?php echo $wuskydayTime4?>,<?php echo $wuskydayTempHigh4; ?>,

<?php echo $wuskydayTime5?>,<?php echo $wuskydayTempHigh5; ?>,
<?php echo $wuskydayTime6?>,<?php echo $wuskydayTempHigh6; ?>,
<?php echo $wuskydayTime7?>,<?php echo $wuskydayTempHigh7; ?>,

<?php echo $wuskydayTime8?>,<?php echo $wuskydayTempHigh8; ?>,
<?php echo $wuskydayTime9?>,<?php echo $wuskydayTempHigh9; ?>,
<?php echo $wuskydayTime10?>,<?php echo $wuskydayTempHigh10; ?>,