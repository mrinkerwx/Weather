<?php include '../common.php';
$email_to = $youremail; // your email address
$email_subject = "Email received via weather station dashboard "; // email subject line
$thankyou = "thankyou.htm"; // thank you page
// If you update the question on the form -
// you need to update the questions answer below
$antispam_answer = 34;
// Do not change this line
$base = "CgpGb3JtIHBvd2VyZWQgYnkgaHR0cHM6Ly93d3cuZnJlZWNvbnRhY3Rmb3JtLmNvbQ==";