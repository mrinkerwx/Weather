  
 <?php include('livedata.php');?>
 <iframe  class="charttempmodule" src="weather34charts/yearsolarmodulechart2.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  
 