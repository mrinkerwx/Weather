  

 <iframe  class="charttempmodule" src="weather34charts/yearavgwindspeedmodulechart2019.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  
