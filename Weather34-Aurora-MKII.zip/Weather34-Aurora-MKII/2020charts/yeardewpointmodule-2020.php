  

 <iframe  class="charttempmodule" src="weather34charts/yeardewpointmodulechart2020.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  
 