  
 <?php include('livedata.php');?>

 <iframe  class="charttempmodule" src="weather34charts/todayairqualitychart-davis-indoor.php" frameborder="0" scrolling="no" width="100%" height="250px"></iframe>  
 